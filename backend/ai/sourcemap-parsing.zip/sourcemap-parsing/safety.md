# Source Map Parsing Safety

## Hard Gates

- Authorized testing only.
- Stay within the confirmed scope. Fetching a publicly-linked `.js`/`.js.map` from an in-scope host is passive (the browser already does it). Extracted endpoints that point at other hosts are leads, not authorization — do not retrieve maps or bundles from out-of-scope hosts without separate authorization.
- Extraction, parsing, reconstruction, and inventory building send **no traffic to the extracted endpoints**. Confirming an endpoint's real method, auth, or response requires sending it a request, which is manual-gated — even a GET.
- Never use, replay, or "just test" a credential, API key, token, bearer, or connection string found inside a source map. Flag it as a sensitive exposure and stop.
- Do not deploy, claim, or modify anything. This specialist is read-only recon and inventory.
- Do not use social engineering as a discovery or delivery mechanism.

## Automatic Lane

Automatic work is limited to: fetching `.js` and `.js.map` resources already served to any visitor from confirmed-in-scope hosts (GET/HEAD); parsing the map JSON locally; writing `sourcesContent` to a local scratch tree; statically scanning reconstructed source for HTTP-client calls, base-URL definitions, and route strings; resolving placeholders from values present in the source or in a publicly-served runtime-config file; normalizing and deduplicating the endpoint inventory; hypothesis generation and confidence scoring. All of this creates no request to any extracted endpoint.

## Manual-Gated Lane

Manual approval is required for: sending any request (including GET) to a discovered endpoint to confirm it is live or to read its response; any state-changing request (POST/PUT/PATCH/DELETE) to a discovered endpoint; using/replaying/validating any secret found in the source; retrieving maps or bundles from hosts beyond the authorized scope; downloading `sourcesContent` that contains another real user's private data beyond confirming its presence and shape; and any handoff into active exploitation under a vulnerability-specific specialist skill (IDOR/BOLA, GraphQL, auth, etc.).

## Stop Conditions

Stop on: discovery of out-of-scope hosts reached only by pivoting through extracted URLs; exposure of another real user's private data inside `sourcesContent`; discovery of live production secrets (capture the shape/location, do not use, escalate as a sensitive-exposure finding); signs of active defense engagement (WAF/IP-ban/CAPTCHA) during any gated live-confirmation step; or any step that would require social engineering to proceed.
